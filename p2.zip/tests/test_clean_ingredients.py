import sys
sys.path.append('..')

from project2 import clean_ingredients
import spacy

all_ingredients = set(['egg', 'milk', 'sugar', 'olive_oil'])
ingredients = [
      "black pepper",
      "shallots",
      "cornflour",
      "cayenne pepper",
      "onions",
      "garlic paste",
      "milk",
      "butter",
      "salt",
      "lemon juice",
      "water",
      "chili powder",
      "passata",
      "oil",
      "ground cumin",
      "boneless chicken skinless thigh",
      "garam masala",
      "double cream",
      "natural yogurt",
      "bay leaf",
      "eggs",
    ]

nlp = spacy.load('en_core_web_sm')
print(ingredients)
print(clean_ingredients(ingredients, nlp, all_ingredients))