import sys
sys.path.append('..')

from project2 import replace_flavour_ingredient

ingredients = ['oil', 'salt', 'egg', 'milk']
print(ingredients)
for ingredient in ingredients:
    print(replace_flavour_ingredient(ingredient))