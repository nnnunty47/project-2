import sys
sys.path.append('..')

from project2 import build_graph

G, graph_dict, prevalance, all_ingredients = build_graph()